def ipa_dictionary():    
    verbs_ipa = {
        "abide": { 
            "bare": "#əbaɪd#", 
            "past": "#əbaɪdɪd#", 
            "prog": "#əbaɪdɪŋ#",
            "pres3sg": "#əbaɪdz#",
            "perfect": "#əbaɪdɪd#" 
        },
        "abolish": {
            "bare": "#əbɑlɪʃ#", 
            "past": "#əbɑlɪʃt#", 
            "prog": "#əbɑlɪʃɪŋ#",
            "pres3sg": "#əbɑlɪʃɪz#",
            "perfect": "#əbɑlɪʃt#" 
        },
         "accept": { 
            "bare": "#əksɛpt#", 
            "past": "#əksɛptɪd#",
            "prog": "#əksɛptɪŋ#", 
            "pres3sg": "#əksɛpts#", 
            "perfect": "#əksɛptɪd#" 
        },
        "acknowledge": {
            "bare": "#əknɑlɪdʒ#",
            "past": "#əknɑlɪdʒd#",
            "prog": "#əknɑlɪdʒɪŋ#",
            "pres3sg": "#əknɑlɪdʒɪz#",
            "perfect": "#əknɑlɪdʒd#"
        },
        "adapt": {
            "bare": "#ədæpt#",
            "past": "#ədæptɪd#",
            "prog": "#ədæptɪŋ#",
            "pres3sg": "#ədæpts#",
            "perfect": "#ədæptɪd#"
        },  
        "admire": {
            "bare": "#ədmaɪɹ#", 
            "past": "#ədmaɪɹd#", 
            "prog": "#ədmaɪɹɪŋ#", 
            "pres3sg": "#ədmaɪɹz#", 
            "perfect": "#ədmaɪɹd#"
        },
        "advise": {
            "bare": "#ədvaɪz#", 
            "past": "#ədvaɪzd#", 
            "prog": "#ədvaɪzɪŋ#", 
            "pres3sg": "#ədvaɪzɪz#", 
            "perfect": "#ədvaɪzd#"
        },
        "afford": {
            "bare": "#ʌfoɹd#", 
            "past": "#ʌfoɹdɪd#", 
            "prog": "#ʌfoɹdɪŋ#",
            "pres3sg": "#ʌfoɹdz#",
            "perfect": "#ʌfoɹdɪd#" 
        },
        "allow": {
            "bare": "#əlaʊ#", 
            "past": "#əlaʊd#", 
            "prog": "#əlaʊɪŋ#", 
            "pres3sg": "#əlaʊz#", 
            "perfect": "#əlaʊd#"
        },
        "amuse": {
            "bare": "#əmjuz#", 
            "past": "#əmjuzd#", 
            "prog": "#əmjuzɪŋ#", 
            "pres3sg": "#əmjuzɪz#", 
                "perfect": "#əmjuzd#"
        },
        "apologize": {
            "bare": "#əpɑlədʒaɪz#",
            "past": "#əpɑlədʒaɪzd#",
            "prog": "#əpɑlədʒaɪzɪŋ#",
            "pres3sg": "#əpɑlədʒaɪzɪz#",
            "perfect": "#əpɑlədʒaɪzd#"
        },
        "arrange": {
            "bare": "#əreɪndʒ#",
            "past": "#əreɪndʒd#",
            "prog": "#əreɪndʒɪŋ#",
            "pres3sg": "#əreɪndʒɪz#",
            "perfect": "#əreɪndʒd#"
        },
        "arise": {
            "bare": "#əɹaɪz#",
            "past": "#əɹoʊz#",
            "prog": "#əɹaɪzɪŋ#",
            "pres3sg": "#əɹaɪzɪz#",
            "perfect": "#əɹɪzən#"
        },
        "arrive": {
            "bare": "#əɹaɪv#",
            "past": "#əɹaɪvd#",
            "prog": "#əɹaɪvɪŋ#",
            "pres3sg": "#əɹaɪvz#",
            "perfect": "#əɹaɪvd#"
        },
        "assist": {
            "bare": "#əsɪst#",
            "past": "#əsɪstɪd#",
            "prog": "#əsɪstɪŋ#",
            "pres3sg": "#əsɪsts#",
            "perfect": "#əsɪstɪd#"
        },
        "ask": {
            "bare": "#æsk#",
            "past": "#æskt#",
            "prog": "#æskɪŋ#",
            "pres3sg": "#æsks#",
            "perfect": "#æskt#"
        },
        "associate": {
            "bare": "#əsoʊʃieɪt#",
            "past": "#əsoʊʃieɪtɪd#",
            "prog": "#əsoʊʃieɪtɪŋ#",
            "pres3sg": "#əsoʊʃieɪts#",
            "perfect": "#əsoʊʃieɪtɪd#"
        },
        "attend": {
            "bare": "#ətɛnd#", 
            "past": "#ətɛndɪd#", 
            "prog": "#ətɛndɪŋ#", 
            "pres3sg": "#ətɛndz#", 
            "perfect": "#ətɛndɪd#"
        },
        "awake": {
            "bare": "#əweɪk#",
            "past": "#əwoʊk#",
            "prog": "#əweɪkɪŋ#",
            "pres3sg": "#əweɪks#",
            "perfect": "#əwoʊkən#"
        },
        "balance": {
            "bare": "#bæləns#",
            "past": "#bælənst#",
            "prog": "#bælənsɪŋ#",
            "pres3sg": "#bælənsɪz#",
            "perfect": "#bælənst#"
        },
        "ban": { 
            "bare": "#bæn#", 
            "past": "#bænd#", 
            "prog": "#bænɪŋ#",
            "pres3sg": "#bænz#",
            "perfect": "#bænd#" 
        },
        "bake": { 
            "bare": "#beɪk#", 
            "past": "#beɪkt#", 
            "prog": "#beɪkɪŋ#", 
            "pres3sg": "#beɪks#", 
            "perfect": "#beɪkt#" 
        },
        "bargain": {
            "bare": "#bɑɹgən#",
            "past": "#bɑɹgənd#",
            "prog": "#bɑɹgənɪŋ#",
            "pres3sg": "#bɑɹgənz#",
            "perfect": "#bɑɹgənd#"
        },
        "bark": {
            "bare": "#bɑɹk#",
            "past": "#bɑɹkt#",
            "prog": "#bɑɹkɪŋ#",
            "pres3sg": "#bɑɹks#",
            "perfect": "#bɑɹkt#"
        },
        "bat": {
            "bare": "#bæt#",
            "past": "#bætɪd#",
            "prog": "#bætɪŋ#",
            "pres3sg": "#bæts#",
            "perfect": "#bætɪd#"
        },
        "bathe": {
            "bare": "#beɪð#",
            "past": "#beɪðd#",
            "prog": "#beɪðɪŋ#",
            "pres3sg": "#beɪðz#",
            "perfect": "#beɪðd#"
        },
        "be": {
            "bare": "#bi#",
            "past": "#wʌz#",
            "prog": "#biɪŋ#",
            "pres3sg": "#ɪz#",
            "perfect": "#bɪn#"
        },
        "beam": {
            "bare": "#bim#",
            "past": "#bimd#",
            "prog": "#bimɪŋ#",
            "pres3sg": "#bimz#",
            "perfect": "#bimd#"
        },
        "bear": {
            "bare": "#bɛɹ#",
            "past": "#bɔɹ#",
            "prog": "#bɛɹɪŋ#",
            "pres3sg": "#bɛɹz#",
            "perfect": "#bɔɹn#"
        },
        "beat": {
            "bare": "#bit#",
            "past": "#bit#",
            "prog": "#bitɪŋ#",
            "pres3sg": "#bits#",
            "perfect": "#bitən#"
        },
        "beckon": {
            "bare": "#bɛkən#",
            "past": "#bɛkənd#",
            "prog": "#bɛkənɪŋ#",
            "pres3sg": "#bɛkənz#",
            "perfect": "#bɛkənd#"
        },
        "become": {
            "bare": "#bɪkʌm#",
            "past": "#bɪkeɪm#",
            "prog": "#bɪkʌmɪŋ#",
            "pres3sg": "#bɪkʌmz#",
            "perfect": "#bɪkʌm#"
        },
        "beep": {
            "bare": "#bip#",
            "past": "#bipt#",
            "prog": "#bipɪŋ#",
            "pres3sg": "#bips#",
            "perfect": "#bipt#"
        },
        "beg": {
            "bare": "#bɛg#",
            "past": "#bɛgd#",
            "prog": "#bɛgɪŋ#",
            "pres3sg": "#bɛgz#",
            "perfect": "#bɛgd#"
        },
        "begin": {
            "bare": "#bɪgɪn#",
            "past": "#bɪgæn#",
            "prog": "#bɪgɪnɪŋ#",
            "pres3sg": "#bɪgɪnz#",
            "perfect": "#bɪgʌn#"
        },
        "believe": {
            "bare": "#bɪliv#",
            "past": "#bɪlivd#",
            "prog": "#bɪlivɪŋ#",
            "pres3sg": "#bɪlivz#",
            "perfect": "#bɪlivd#"
        },
        "bend": {
            "bare": "#bɛnd#",
            "past": "#bɛnt#",
            "prog": "#bɛndɪŋ#",
            "pres3sg": "#bɛndz#",
            "perfect": "#bɛnt#"
        },
        "benefit": { 
            "bare": "#bɛnəfɪt#", 
            "past": "#bɛnəfɪtɪd#", 
            "prog": "#bɛnəfɪtɪŋ#",
            "pres3sg": "#bɛnəfɪts#",
            "perfect": "#bɛnəfɪtɪd#"  
        },
        "bet": {
            "bare": "#bɛt#",
            "past": "#bɛt#",
            "prog": "#bɛtɪŋ#",
            "pres3sg": "#bɛts#",
            "perfect": "#bɛt#"
        },
        "beware": {
            "bare": "#bɪwɛɹ#",
            "past": "#bɪwɛɹd#",
            "prog": "#bɪwɛɹɪŋ#",
            "pres3sg": "#bɪwɛɹz#",
            "perfect": "#bɪwɛɹd#"
        },
        "bewitch": {
            "bare": "#bɪwɪtʃ#",
            "past": "#bɪwɪtʃt#",
            "prog": "#bɪwɪtʃɪŋ#",
            "pres3sg": "#bɪwɪtʃɪz#",
            "perfect": "#bɪwɪtʃt#"
        },
        "bind": {
            "bare": "#baɪnd#",
            "past": "#baʊnd#",
            "prog": "#baɪndɪŋ#",
            "pres3sg": "#baɪndz#",
            "perfect": "#baʊnd#"
        },
        "bite": {
            "bare": "#baɪt#",
            "past": "#bɪt#",
            "prog": "#baɪtɪŋ#",
            "pres3sg": "#baɪts#",
            "perfect": "#bɪtən#"
        },
        "bleed": {
            "bare": "#blid#",
            "past": "#blɛd#",
            "prog": "#blidɪŋ#",
            "pres3sg": "#blidz#",
            "perfect": "#blɛd#"
        },
        "bless": {
            "bare": "#blɛs#",
            "past": "#blɛst#",
            "prog": "#blɛsɪŋ#",
            "pres3sg": "#blɛsɪz#",
            "perfect": "#blɛst#"
        },
        "blink": {
            "bare": "#blɪŋk#",
            "past": "#blɪŋkt#",
            "prog": "#blɪŋkɪŋ#",
            "pres3sg": "#blɪŋks#",
            "perfect": "#blɪŋkt#"
        },
        "blister": {
             "bare": "#blɪstəɹ#",
            "past": "#blɪstəɹd#",
            "prog": "#blɪstəɹɪŋ#",
            "pres3sg": "#blɪstəɹz#",
            "perfect": "#blɪstəɹd#"
        },
        "blow": {
            "bare": "#bloʊ#",
            "past": "#blu#",
            "prog": "#bloʊɪŋ#",
            "pres3sg": "#bloʊz#",
            "perfect": "#bloʊn#"
        },
        "blurt": {
            "bare": "#blɝt#",
            "past": "#blɝtɪd#",
            "prog": "#blɝtɪŋ#",
            "pres3sg": "#blɝts#",
            "perfect": "#blɝtɪd#"
        },
        "boast": {
            "bare": "#boʊst#",
            "past": "#boʊstɪd#",
            "prog": "#boʊstɪŋ#",
            "pres3sg": "#boʊsts#",
            "perfect": "#boʊstɪd#"
        },
        "boil": {
            "bare": "#bɔɪl#",
            "past": "#bɔɪld#",
            "prog": "#bɔɪlɪŋ#",
            "pres3sg": "#bɔɪlz#",
            "perfect": "#bɔɪld#"
        },
        "bolster": {
            "bare": "#boʊlstəɹ#",
            "past": "#boʊlstəɹd#",
            "prog": "#boʊlstəɹɪŋ#",
            "pres3sg": "#boʊlstəɹz#",
            "perfect": "#boʊlstəɹd#"
        },
        "bounce": {
            "bare": "#baʊns#",
            "past": "#baʊnst#",
            "prog": "#baʊnsɪŋ#",
            "pres3sg": "#baʊnsɪz#",
            "perfect": "#baʊnst#"
        },
        "bow": {
            "bare": "#baʊ#",
            "past": "#baʊd#",
            "prog": "#baʊɪŋ#",
            "pres3sg": "#baʊz#",
            "perfect": "#baʊd#"
        },
        "brace": {
            "bare": "#breɪs#",
            "past": "#breɪst#",
            "prog": "#breɪsɪŋ#",
            "pres3sg": "#breɪsɪz#",
            "perfect": "#breɪst#"
        },
        "break": {
            "bare": "#bɹeɪk#",
            "past": "#bɹoʊk#",
            "prog": "#bɹeɪkɪŋ#",
            "pres3sg": "#bɹeɪks#",
            "perfect": "#bɹoʊkən#"
        },
        "bring": {
            "bare": "#bɹɪŋ#",
            "past": "#bɹɔt#",
            "prog": "#bɹɪŋɪŋ#",
            "pres3sg": "#bɹɪŋz#",
            "perfect": "#bɹɔt#"
        },
        "broadcast": {
            "bare": "#bɹɔdkæst#",
            "past": "#bɹɔdkæst#",
            "prog": "#bɹɔdkæstɪŋ#",
            "pres3sg": "#bɹɔdkæsts#",
            "perfect": "#bɹɔdkæst#"
        },
        "bruise": {
            "bare": "#bɹuz#",
            "past": "#bɹuzd#",
            "prog": "#bɹuzɪŋ#",
            "pres3sg": "#bɹuzɪz#",
            "perfect": "#bɹuzd#"
        },
        "brush": {
            "bare": "#bɹʌʃ#",
            "past": "#bɹʌʃt#",
            "prog": "#bɹʌʃɪŋ#",
            "pres3sg": "#bɹʌʃɪz#",
            "perfect": "#bɹʌʃt#"
        },
        "build": {
            "bare": "#bɪld#",
            "past": "#bɪlt#",
            "prog": "#bɪldɪŋ#",
            "pres3sg": "#bɪldz#",
            "perfect": "#bɪlt#"
        },
        "bundle": {
            "bare": "#bʌndl#",
            "past": "#bʌndld#",
            "prog": "#bʌndlɪŋ#",
            "pres3sg": "#bʌndlz#",
            "perfect": "#bʌndld#"
        },
        "burden": {
            "bare": "#bɝdən#",
            "past": "#bɝdənd#",
            "prog": "#bɝdənɪŋ#",
            "pres3sg": "#bɝdənz#",
            "perfect": "#bɝdənd#"
        },
        "burst": {
            "bare": "#bɝst#",
            "past": "#bɝst#",
            "prog": "#bɝstɪŋ#",
            "pres3sg": "#bɝsts#",
            "perfect": "#bɝst#"
        },
        "buy": {
            "bare": "#baɪ#",
            "past": "#bɔt#",
            "prog": "#baɪɪŋ#",
            "pres3sg": "#baɪz#",
            "perfect": "#bɔt#"
        },
        "calculate": {
            "bare": "#kælkjəleɪt#",
            "past": "#kælkjəleɪtɪd#",
            "prog": "#kælkjəleɪtɪŋ#",
            "pres3sg": "#kælkjəleɪts#",
            "perfect": "#kælkjəleɪtɪd#"
        },
        "call": {
            "bare": "#kɔl#",  
            "past": "#kɔld#", 
            "prog": "#kɔlɪŋ#",
            "pres3sg": "#kɔlz#",
            "perfect": "#kɔld#" 
        },
        "camp": { 
            "bare": "#kæmp#", 
            "past": "#kæmpt#", 
            "prog": "#kæmpɪŋ#",
            "pres3sg": "#kæmps#",
            "perfect": "#kæmpt#" 
        },
        "can": {
            "bare": "#kæn#", 
            "past": "#kʊd#", 
            "prog": "No Progressive",
            "pres3sg": "#kæn#",
            "perfect": "No Perfect Participle" 
        },
        "capture": {
            "bare": "#kæptʃəɹ#",
            "past": "#kæptʃəɹd#",
            "prog": "#kæptʃəɹɪŋ#",
            "pres3sg": "#kæptʃəɹz#",
            "perfect": "#kæptʃəɹd#"
        },
        "carve": {
            "bare": "#kɑɹv#",
            "past": "#kɑɹvd#",
            "prog": "#kɑɹvɪŋ#",
            "pres3sg": "#kɑɹvz#",
            "perfect": "#kɑɹvd#"
        },
        "catch": {
            "bare": "#kæʧ#",
            "past": "#kɔt#",
            "prog": "#kæʧɪŋ#",
            "pres3sg": "#kæʧɪz#",
            "perfect": "#kɔt#"
        },
        "celebrate": {
            "bare": "#sɛləbreɪt#",
            "past": "#sɛləbreɪtɪd#",
            "prog": "#sɛləbreɪtɪŋ#",
            "pres3sg": "#sɛləbreɪts#",
            "perfect": "#sɛləbreɪtɪd#"
        },
        "challenge": {
            "bare": "#tʃælɪndʒ#",
            "past": "#tʃælɪndʒd#",
            "prog": "#tʃælɪndʒɪŋ#",
            "pres3sg": "#tʃælɪndʒɪz#",
            "perfect": "#tʃælɪndʒd#"
        },
        "change": {
            "bare": "#tʃeɪndʒ#",
            "past": "#tʃeɪndʒd#",
            "prog": "#tʃeɪndʒɪŋ#",
            "pres3sg": "#tʃeɪndʒɪz#",
            "perfect": "#tʃeɪndʒd#"
        },
        "charge": {
            "bare": "#tʃɑɹdʒ#",
            "past": "#tʃɑɹdʒd#",
            "prog": "#tʃɑɹdʒɪŋ#",
            "pres3sg": "#tʃɑɹdʒɪz#",
            "perfect": "#tʃɑɹdʒd#"
        },
        "cheer": {
            "bare": "#tʃɪɹ#",
            "past": "#tʃɪɹd#",
            "prog": "#tʃɪɹɪŋ#",
            "pres3sg": "#tʃɪɹz#",
            "perfect": "#tʃɪɹd#"
        },
        "chew": {
            "bare": "#tʃu#",
            "past": "#tʃud#",
            "prog": "#tʃuɪŋ#",
            "pres3sg": "#tʃuz#",
            "perfect": "#tʃud#"
        },
        "choose": {
            "bare": "#ʧuz#",
            "past": "#ʧoʊz#",
            "prog": "#ʧuzɪŋ#",
            "pres3sg": "#ʧuzɪz#",
            "perfect": "#ʧoʊzən#"
        },
        "clap": { 
            "bare": "#klæp#", 
            "past": "#klæpt#", 
            "prog": "#klæpɪŋ#",
            "pres3sg": "#klæps#",
            "perfect": "#klæpt#" 
        },
        "clarify": {
            "bare": "#klɛɹəfaɪ#",
            "past": "#klɛɹəfaɪd#",
            "prog": "#klɛɹəfaɪɪŋ#",
            "pres3sg": "#klɛɹəfaɪz#",
            "perfect": "#klɛɹəfaɪd#"
        },
        "classify": {
            "bare": "#klæsəfaɪ#",
            "past": "#klæsəfaɪd#",
            "prog": "#klæsəfaɪɪŋ#",
            "pres3sg": "#klæsəfaɪz#",
            "perfect": "#klæsəfaɪd#"
        },
        "clean": { 
            "bare": "#klin#",
            "past": "#klind#",
            "prog": "#klinɪŋ#", 
            "pres3sg": "#klinz#", 
            "perfect": "#klind#" 
        },
        "cleanse": {
            "bare": "#klɛnz#",
            "past": "#klɛnzd#",
            "prog": "#klɛnzɪŋ#",
            "pres3sg": "#klɛnzɪz#",
            "perfect": "#klɛnzd#"
        },
        "come": {
            "bare": "#kʌm#",
            "past": "#keɪm#",
            "prog": "#kʌmɪŋ#",
            "pres3sg": "#kʌmz#",
            "perfect": "#kʌm#"
        },
        "command": {
            "bare": "#kəmænd#",
            "past": "#kəmændɪd#",
            "prog": "#kəmændɪŋ#",
            "pres3sg": "#kəmændz#",
            "perfect": "#kəmændɪd#"
        },
        "compare": {
            "bare": "#kəmpɛɹ#",
            "past": "#kəmpɛɹd#",
            "prog": "#kəmpɛɹɪŋ#",
            "pres3sg": "#kəmpɛɹz#",
            "perfect": "#kəmpɛɹd#"
        },
        "confront": {
            "bare": "#kənfɹʌnt#",
            "past": "#kənfɹʌntɪd#",
            "prog": "#kənfɹʌntɪŋ#",
            "pres3sg": "#kənfɹʌnts#",
            "perfect": "#kənfɹʌntɪd#"
        },
        "cost": {
            "bare": "#kɔst#",
            "past": "#kɔst#",
            "prog": "#kɔstɪŋ#",
            "pres3sg": "#kɔsts#",
            "perfect": "#kɔst#"
        },
        "could": {
            "bare": "#kʊd#", 
            "past": "#kʊd#", 
            "prog": "No Progressive",
            "pres3sg": "#kʊd#",
            "perfect": "No Perfect Participle" 
        },
        "creep": {
            "bare":"#kɹip#",
            "past":"#kɹɛpt#",
            "prog":"#kɹipɪŋ#",
            "pres3sg":"#kɹips#",
            "perfect":"#kɹɛpt#"
        },
        "cut": {
            "bare":"#kʌt#",
            "past":"#kʌt#",
            "prog":"#kʌtɪŋ#",
            "pres3sg":"#kʌts#",
            "perfect":"#kʌt#"
        },
        "deactivate": { 
            "bare": "#diæktɪveɪt#", 
            "past": "#diæktɪveɪtɪd#",
            "prog": "#diæktɪveɪtɪŋ#",
            "pres3sg": "#diæktɪveɪts#", 
            "perfect": "#diæktɪveɪtɪd#" 
        },
        "deal": {
            "bare":"#dil#",
            "past":"#dɛlt#",
            "prog":"#dilɪŋ#",
            "pres3sg":"#dilz#",
            "perfect":"#dɛlt#"
        },
        "decorate": { 
            "bare": "#dɛkəɹeɪt#", 
            "past": "#dɛkəɹeɪtɪd#", 
            "prog": "#dɛkəɹeɪtɪŋ#", 
            "pres3sg": "#dɛkəɹeɪts#", 
            "perfect": "#dɛkəɹeɪtɪd#" 
        },
        "develop": { 
            "bare": "#dɪvɛləp#", 
            "past": "#dɪvɛləpt#",
            "prog": "#dɪvɛləpɪŋ#",
            "pres3sg": "#dɪvɛləps#", 
            "perfect": "#dɪvɛləpt#" 
        },
        "dig": {
            "bare":"#dɪg#",
            "past":"#dʌg#",
            "prog":"#dɪgɪŋ#",
            "pres3sg":"#dɪgz#",
            "perfect":"#dʌg#"
        },
        "dip": { 
            "bare": "#dɪp#", 
            "past": "#dɪpt#",
            "prog": "#dɪpɪŋ#",
            "pres3sg": "#dɪps#", 
            "perfect": "#dɪpt#" 
        },
        "disappear": { 
            "bare": "#dɪsəpɪɹ#", 
            "past": "#dɪsəpɪɹd#",
            "prog": "#dɪsəpɪɹɪŋ#",
            "pres3sg": "#dɪsəpɪɹz#", 
            "perfect": "#dɪsəpɪɹd#" 
        },
        "dive": {
            "bare":"#daɪv#",
            "past":"#doʊv#",
            "prog":"#daɪvɪŋ#",
            "pres3sg":"#daɪvz#",
            "perfect":"#doʊv#"
        },
        "do": {
            "bare":"#du#",
            "past":"#dɪd#",
            "prog":"#duɪŋ#",
            "pres3sg":"#dʌz#",
            "perfect":"#dʌn#"
        },
        "draw": {
            "bare":"#dɹɔ#",
            "past":"#dɹu#",
            "prog":"#dɹɔɪŋ#",
            "pres3sg":"#dɹɔz#",
            "perfect":"#dɹɔn#"
        },
        "dream": {
            "bare":"#dɹim#",
            "past":"#dɹɛmt#",
            "prog":"#dɹimɪŋ#",
            "pres3sg":"#dɹimz#",
            "perfect":"#dɹɛmt#"
        },
        "drink": {
            "bare":"#dɹɪŋk#",
            "past":"#dɹæŋk#",
            "prog":"#dɹɪŋkɪŋ#",
            "pres3sg":"#dɹɪŋks#",
            "perfect":"#dɹʌŋk#"
        },
        "drive": {
            "bare":"#dɹaɪv#",
            "past":"#dɹoʊv#",
            "prog":"#dɹaɪvɪŋ#",
            "pres3sg":"#dɹaɪvz#",
            "perfect":"#dɹɪvən#"
        },
        "dwell": { 
            "bare": "#dwɛl#", 
            "past": "#dwɛld#",
            "prog": "#dwɛlɪŋ#",
            "pres3sg": "#dwɛlz#", 
            "perfect": "#dwɛld#" 
        },
        "earn": { 
            "bare": "#ɝn#", 
            "past": "#ɝnd#",
            "prog": "#ɝnɪŋ#",
            "pres3sg": "#ɝnz#", 
            "perfect": "#ɝnd#" 
        },
        "eat": {
            "bare":"#it#",
            "past":"#eɪt#",
            "prog":"#itɪŋ#",
            "pres3sg":"#its#",
            "perfect":"#itən#"
        },
        "eliminate": { 
            "bare": "#ɪlɪməneɪt#", 
            "past": "#ɪlɪməneɪtɪd#",
            "prog": "#ɪlɪməneɪtɪŋ#",
            "pres3sg": "#ɪlɪməneɪts#", 
            "perfect": "#ɪlɪməneɪtɪd#" 
        },
        "embrace": { 
            "bare": "#ɪmbɹeɪs#", 
            "past": "#ɪmbɹeɪst#",
            "prog": "#ɪmbɹeɪsɪŋ#",
            "pres3sg": "#ɪmbɹeɪsɪz#", 
            "perfect": "#ɪmbɹeɪst#" 
        },
        "enjoy": { 
            "bare": "#ɪnʤɔɪ#", 
            "past": "#ɪnʤɔɪd#", 
            "prog": "#ɪnʤɔɪɪŋ#", 
            "pres3sg": "#ɪnʤɔɪz#", 
            "perfect": "#ɪnʤɔɪd#" 
        },
       "evaporate": { 
            "bare": "#ɪvæpəɹeɪt#", 
            "past": "#ɪvæpəɹeɪtɪd#",
            "prog": "#ɪvæpəɹeɪtɪŋ#",
            "pres3sg": "#ɪvæpəɹeɪts#", 
            "perfect": "#ɪvæpəɹeɪtɪd#" 
        },
         "face": { 
            "bare": "#feɪs#", 
            "past": "#feɪst#",
            "prog": "#feɪsɪŋ#",
            "pres3sg": "#feɪsɪz#", 
            "perfect": "#feɪst#" 
        },
        "fall": {
            "bare":"#fɔl#",
            "past":"#fɛl#",
            "prog":"#fɔlɪŋ#",
            "pres3sg":"#fɔlz#",
            "perfect":"#fɔlən#"
        },
        "feed": {
            "bare":"#fid#",
            "past":"#fɛd#",
            "prog":"#fidɪŋ#",
            "pres3sg":"#fidz#",
            "perfect":"#fɛd#"
        },
        "feel": {
            "bare":"#fil#",
            "past":"#fɛlt#",
            "prog":"#filɪŋ#",
            "pres3sg":"#filz#",
            "perfect":"#fɛlt#"
        },
        "fidget": { 
            "bare": "#fɪdʒɪt#", 
            "past": "#fɪdʒɪtɪd#",
            "prog": "#fɪdʒɪtɪŋ#",
            "pres3sg": "#fɪdʒɪts#", 
            "perfect": "#fɪdʒɪtɪd#" 
        },
        "fight": {
            "bare":"#faɪt#",
            "past":"#fɔt#",
            "prog":"#faɪtɪŋ#",
            "pres3sg":"#faɪts#",
            "perfect":"#fɔt#"
        },
        "find": {
            "bare":"#faɪnd#",
            "past":"#faʊnd#",
            "prog":"#faɪndɪŋ#",
            "pres3sg":"#faɪndz#",
            "perfect":"#faʊnd#"
        },
        "fit": {
            "bare":"#fɪt#",
            "past":"#fɪt#",
            "prog":"#fɪtɪŋ#",
            "pres3sg":"#fɪts#",
            "perfect":"#fɪt#"
        },
        "fix": { 
            "bare": "#fɪks#", 
            "past": "#fɪkst#", 
            "prog": "#fɪksɪŋ#", 
            "pres3sg": "#fɪksɪz#", 
            "perfect": "#fɪkst#" 
        },
        "flee": {
            "bare":"#fli#",
            "past":"#flɛd#",
            "prog":"#fliɪŋ#",
            "pres3sg":"#fliz#",
            "perfect":"#flɛd#"
        },
        "fling": {
            "bare":"#flɪŋ#",
            "past":"#flʌŋ#",
            "prog":"#flɪŋɪŋ#",
            "pres3sg":"#flɪŋz#",
            "perfect":"#flʌŋ#"
        },
        "flush": { 
            "bare": "#flʌʃ#", 
            "past": "#flʌʃt#",
            "prog": "#flʌʃɪŋ#",
            "pres3sg": "#flʌʃɪz#", 
            "perfect": "#flʌʃt#" 
        },
        "fly": {
            "bare":"#flaɪ#",
            "past":"#flu#",
            "prog":"#flaɪɪŋ#",
            "pres3sg":"#flaɪz#",
            "perfect":"#floʊn#"
        },
        "forbid": {
            "bare":"#fəɹbɪd#",
            "past":"#fəɹbeɪd#",
            "prog":"#fəɹbɪdɪŋ#",
            "pres3sg":"#fəɹbɪdz#",
            "perfect":"#fəɹbɪdən#"
        },
        "forget": {
            "bare":"#fəɹgɛt#",
            "past":"#fəɹgɑt#",
            "prog":"#fəɹgɛtɪŋ#",
            "pres3sg":"#fəɹgɛts#",
            "perfect":"#fəɹgɑtən#"
        },
        "forgive": {
            "bare": "#fəɹɡɪv#",
            "past": "#fəɹɡeɪv#",
            "prog": "#fəɹɡɪvɪŋ#",
            "pres3sg": "#fəɹɡɪvs#",
            "perfect": "#fəɹɡɪvən#",
        },
        "fray": { 
            "bare": "#fɹeɪ#", 
            "past": "#fɹeɪd#",
            "prog": "#fɹeɪŋ#",
            "pres3sg": "#fɹeɪz#", 
            "perfect": "#fɹeɪd#" 
        },
        "freeze": {
            "bare": "#fɹiz#",
            "past": "#fɹoʊz#",
            "prog": "#fɹizɪŋ#",
            "pres3sg": "#fɹizɪz#",
            "perfect": "#fɹoʊzən#"
        },
        "gain": { 
            "bare": "#geɪn#", 
            "past": "#geɪnd#",
            "prog": "#geɪnɪŋ#",
            "pres3sg": "#geɪnz#", 
            "perfect": "#geɪnd#" 
        },
        "gather": { 
            "bare": "#ɡæðəɹ#", 
            "past": "#ɡæðəɹd#",
            "prog": "#ɡæðəɹɪŋ#",
            "pres3sg": "#ɡæðəɹz#", 
            "perfect": "#ɡæðəɹd#" 
        },
        "generate": { 
            "bare": "#ʤɛnəɹeɪt#", 
            "past": "#ʤɛnəɹeɪtɪd#",
            "prog": "#ʤɛnəɹeɪtɪŋ#",
            "pres3sg": "#ʤɛnəɹeɪts#", 
            "perfect": "#ʤɛnəɹeɪtɪd#" 
        },
        "get": {
            "bare": "#ɡet#",
            "past": "#ɡɑt#",
            "prog": "#ɡetɪŋ#",
            "pres3sg": "#ɡets#",
            "perfect": "#ɡɑtn#"
        },
        "give": {
            "bare": "#ɡɪv#",
            "past": "#ɡeɪv#",
            "prog": "#ɡɪvɪŋ#",
            "pres3sg": "#ɡɪvs#",
            "perfect": "#ɡɪvən#"
        },
        "go": {
            "bare": "#ɡoʊ#",
            "past": "#wɛnt#",
            "prog": "#ɡoʊɪŋ#",
            "pres3sg": "#ɡoʊz#",
            "perfect": "#ɡɑn#"
        },
        "grab": { 
            "bare": "#ɡɹæb#", 
            "past": "#ɡɹæbd#",
            "prog": "#ɡɹæbɪŋ#",
            "pres3sg": "#ɡɹæbz#", 
            "perfect": "#ɡɹæbd#" 
        },
        "grow": {
            "bare": "#ɡɹoʊ#",
            "past": "#ɡɹu#",
            "prog": "#ɡɹoʊɪŋ#",
            "pres3sg": "#ɡɹoʊz#",
            "perfect": "#ɡɹoʊn#"
        },
        "halt": { 
            "bare": "#hɔlt#", 
            "past": "#hɔltɪd#",
            "prog": "#hɔltɪŋ#",
            "pres3sg": "#hɔlts#", 
            "perfect": "#hɔltɪd#" 
        },
        "hang": {
            "bare": "#hæŋ#",
            "past": "#hʌŋ#",
            "prog": "#hæŋɪŋ#",
            "pres3sg": "#hæŋz#",
            "perfect": "#hʌŋ#"
        },
        "have": {
            "bare": "#hæz#",
            "past": "#hæd#",
            "prog": "#hævɪŋ#",
            "pres3sg": "#hævz#",
            "perfect": "#hæd#"
        },
        "heal": { 
            "bare": "#hil#", 
            "past": "#hild#",
            "prog": "#hilɪŋ#",
            "pres3sg": "#hilz#", 
            "perfect": "#hild#" 
        },
        "hear": {
            "bare": "#hɪɹ#",
            "past": "#hɜɹd#",
            "prog": "#hɪɹɪŋ#",
            "pres3sg": "#hɪɹz#",
            "perfect": "#hɜɹd#"
        },
        "help": { 
            "bare": "#hɛlp#",
            "past": "#hɛlpt#", 
            "prog": "#hɛlpɪŋ#", 
            "pres3sg": "#hɛlps#", 
            "perfect": "#hɛlpt#" 
        },
        "hide": {
            "bare": "#haɪd#",
            "past": "#hɪd#",
            "prog": "#haɪdɪŋ#",
            "pres3sg": "#haɪdz#",
            "perfect": "#hɪdən#"
        },
        "hint": { 
            "bare": "#hɪnt#", 
            "past": "#hɪntɪd#",
            "prog": "#hɪntɪŋ#",
            "pres3sg": "#hɪnts#", 
            "perfect": "#hɪntɪd#" 
        },
        "hit": {
            "bare": "#hɪt#",
            "past": "#hɪt#",
            "prog": "#hɪtɪŋ#",
            "pres3sg": "#hɪts#",
            "perfect": "#hɪt#"
        },
        "hold": {
            "bare": "#hoʊld#",
            "past": "#hɛld#",
            "prog": "#hoʊldɪŋ#",
            "pres3sg": "#hoʊldz#",
            "perfect": "#hɛld#"
        },
        "holler": { 
            "bare": "#hɑləɹ#", 
            "past": "#hɑləɹd#",
            "prog": "#hɑləɹɪŋ#",
            "pres3sg": "#hɑləɹz#", 
            "perfect": "#hɑləɹd#" 
        },
        "host": { 
            "bare": "#hoʊst#", 
            "past": "#hoʊstɪd#",
            "prog": "#hoʊstɪŋ#",
            "pres3sg": "#hoʊsts#", 
            "perfect": "#hoʊstɪd#" 
        },
        "hurt": {
            "bare": "#hɜɹt#",
            "past": "#hɜɹt#",
            "prog": "#hɜɹtɪŋ#",
            "pres3sg": "#hɜɹts#",
            "perfect": "#hɜɹt#"
        },
        "idealize": { 
            "bare": "#aɪdiəlaɪz#", 
            "past": "#aɪdiəlaɪzd#",
            "prog": "#aɪdiəlaɪzɪŋ#",
            "pres3sg": "#aɪdiəlaɪzɪz#", 
            "perfect": "#aɪdiəlaɪzd#" 
        },
        "identify": { 
            "bare": "#aɪdɛntɪfaɪ#", 
            "past": "#aɪdɛntɪfaɪd#",
            "prog": "#aɪdɛntɪfaɪŋ#",
            "pres3sg": "#aɪdɛntɪfaɪz#", 
            "perfect": "#aɪdɛntɪfaɪd#" 
        },
        "ignore": { 
            "bare": "#ɪɡnɔɹ#", 
            "past": "#ɪɡnɔɹd#",
            "prog": "#ɪɡnɔɹɪŋ#",
            "pres3sg": "#ɪɡnɔɹz#", 
            "perfect": "#ɪɡnɔɹd#" 
        },
        "improve": { 
            "bare": "#ɪmpɹuv#", 
            "past": "#ɪmpɹuvd#",
            "prog": "#ɪmpɹuvɪŋ#",
            "pres3sg": "#ɪmpɹuvz#", 
            "perfect": "#ɪmpɹuvd#" 
        },
        "index": { 
            "bare": "#ɪndɛks#", 
            "past": "#ɪndɛkst#",
            "prog": "#ɪndɛksɪŋ#",
            "pres3sg": "#ɪndɛksɪz#", 
            "perfect": "#ɪndɛkst#" 
        },
        "invite": { 
            "bare": "#ɪnvaɪt#", 
            "past": "#ɪnvaɪtɪd#", 
            "prog": "#ɪnvaɪtɪŋ#", 
            "pres3sg": "#ɪnvaɪts#", 
            "perfect": "#ɪnvaɪtɪd#" 
        },
        "iron": { 
            "bare": "#aɪəɹn#", 
            "past": "#aɪəɹnd#",
            "prog": "#aɪəɹnɪŋ#",
            "pres3sg": "#aɪəɹnz#", 
            "perfect": "#aɪəɹnd#" 
        },
        "jog": { 
            "bare": "#ʤɑɡ#", 
            "past": "#ʤɑɡd#",
            "prog": "#ʤɑɡɪŋ#",
            "pres3sg": "#ʤɑɡz#", 
            "perfect": "#ʤɑɡd#" 
        },
        "join": { 
            "bare": "#ʤɔɪn#", 
            "past": "#ʤɔɪnd#",
            "prog": "#ʤɔɪnɪŋ#",
            "pres3sg": "#ʤɔɪnz#", 
            "perfect": "#ʤɔɪnd#" 
        },
        "jot": { 
            "bare": "#ʤɑt#", 
            "past": "#ʤɑtɪd#",
            "prog": "#ʤɑtɪŋ#",
            "pres3sg": "#ʤɑts#", 
            "perfect": "#ʤɑtɪd#" 
        },
        "juice": { 
            "bare": "#ʤus#", 
            "past": "#ʤust#",
            "prog": "#ʤusɪŋ#",
            "pres3sg": "#ʤusɪz#", 
            "perfect": "#ʤust#" 
        },
        "justify": { 
            "bare": "#ʤʌstɪfaɪ#", 
            "past": "#ʤʌstɪfaɪd#",
            "prog": "#ʤʌstɪfaɪɪŋ#",
            "pres3sg": "#ʤʌstɪfaɪz#", 
            "perfect": "#ʤʌstɪfaɪd#" 
        },
        "keep": { 
            "bare": "#kip#", 
            "past": "#kɛpt#", 
            "prog": "#kipɪŋ#", 
            "pres3sg": "#kips#", 
            "perfect": "#kɛpt#"
        },
        "kick": { 
            "bare": "#kɪk#", 
            "past": "#kɪkt#",
            "prog": "#kɪkɪŋ#",
            "pres3sg": "#kɪks#", 
            "perfect": "#kɪkt#" 
        },
        "kiss": { 
            "bare": "#kɪs#", 
            "past": "#kɪst#",
            "prog": "#kɪsɪŋ#",
            "pres3sg": "#kɪsɪz#", 
            "perfect": "#kɪst#" 
        },
        "know": { 
            "bare": "#noʊ#", 
            "past": "#nu#", 
            "prog": "#noʊɪŋ#", 
            "pres3sg": "#noʊz#", 
            "perfect": "#noʊn#" 
        },
        "label": { 
            "bare": "#leɪbəl#", 
            "past": "#leɪbəld#",
            "prog": "#leɪbəlɪŋ#",
            "pres3sg": "#leɪbəlz#", 
            "perfect": "#leɪbəld#" 
        },
        "lag": { 
            "bare": "#læɡ#", 
            "past": "#læɡd#",
            "prog": "#læɡɪŋ#",
            "pres3sg": "#læɡz#", 
            "perfect": "#læɡd#" 
        },
        "land": { 
            "bare": "#lænd#", 
            "past": "#lændɪd#",
            "prog": "#lændɪŋ#",
            "pres3sg": "#lændz#", 
            "perfect": "#lændɪd#" 
        },
        "last": { 
            "bare": "#læst#", 
            "past": "#læstɪd#",
            "prog": "#læstɪŋ#",
            "pres3sg": "#læsts#", 
            "perfect": "#læstɪd#" 
        },
        "lay": { 
            "bare": "#leɪ#", 
            "past": "#leɪd#", 
            "prog": "#leɪɪŋ#", 
            "pres3sg": "#leɪz#", 
            "perfect": "#leɪd#" 
        },
        "lead": { 
            "bare": "#lid#", 
            "past": "#lɛd#", 
            "prog": "#lidɪŋ#", 
            "pres3sg": "#lidz#",
            "perfect": "#lɛd#"
        },
        "lean": { 
            "bare": "#lin#", 
            "past": "#lind#",
            "prog": "#linɪŋ#",
            "pres3sg": "#linz#", 
            "perfect": "#lind#" 
        },
        "leave": {
            "bare": "#liv#", 
            "past": "#lɛft#", 
            "prog": "#livɪŋ#", 
            "pres3sg": "#livz#", 
            "perfect": "#lɛft#" 
        },
        "lend": { 
            "bare": "#lɛnd#", 
            "past": "#lɛnt#", 
            "prog": "#lɛndɪŋ#", 
            "pres3sg": "#lɛndz#", 
            "perfect": "#lɛnt#" 
        },
        "let": { 
            "bare": "#lɛt#", 
            "past": "#lɛt#", 
            "prog": "#lɛtɪŋ#", 
            "pres3sg": "#lɛts#", 
            "perfect": "#lɛt#" 
        },
        "lie": { 
            "bare": "#laɪ#", 
            "past": "#laɪd#", 
            "prog": "#laɪɪŋ#", 
            "pres3sg": "#laɪz#", 
            "perfect": "#laɪd#" 
        },
        "lift": { 
            "bare": "#lɪft#", 
            "past": "#lɪftɪd#",
            "prog": "#lɪftɪŋ#",
            "pres3sg": "#lɪfts#", 
            "perfect": "#lɪftɪd#" 
        },
        "light": { 
            "bare": "#laɪt#", 
            "past": "#lɪt#", 
            "prog": "#laɪtɪŋ#", 
            "pres3sg": "#laɪts#", 
            "perfect": "#lɪt#" 
        },
        "listen": { 
            "bare": "#lɪsən#", 
            "past": "#lɪsənd#", 
            "prog": "#lɪsənɪŋ#", 
            "pres3sg": "#lɪsənz#", 
            "perfect": "#lɪsənd#" 
        },
        "lose": { 
            "bare": "#luz#", 
            "past": "#lɔst#", 
            "prog": "#luzɪŋ#", 
            "pres3sg": "#luzɪz#", 
            "perfect": "#lɔst#" 
        },
        "mail": { 
            "bare": "#meɪl#", 
            "past": "#meɪld#",
            "prog": "#meɪlɪŋ#",
            "pres3sg": "#meɪlz#", 
            "perfect": "#meɪld#" 
        },
        "make": { 
            "bare": "#meɪk#", 
            "past": "#meɪd#", 
            "prog": "#meɪkɪŋ#", 
            "pres3sg": "#meɪks#", 
            "perfect": "#meɪd#" 
        },
        "manipulate": { 
            "bare": "#mənɪpjəleɪt#", 
            "past": "#mənɪpjəleɪtɪd#",
            "prog": "#mənɪpjəleɪtɪŋ#",
            "pres3sg": "#mənɪpjəleɪts#", 
            "perfect": "#mənɪpjəleɪtɪd#" 
        },
        "map": { 
            "bare": "#mæp#", 
            "past": "#mæpt#",
            "prog": "#mæpɪŋ#",
            "pres3sg": "#mæps#", 
            "perfect": "#mæpt#" 
        },
         "may": {
            "bare": "#meɪ#",
            "past": "#maɪt#",
            "prog": "No Progressive",
            "pres3sg": "#meɪ#",
            "perfect": "No Perfect Participle"
        },
        "mean": { 
            "bare": "#min#", 
            "past": "#mɛnt#", 
            "prog": "#minɪŋ#", 
            "pres3sg": "#minz#", 
            "perfect": "#mɛnt#" 
        },
        "meet": { 
            "bare": "#mit#", 
            "past": "#mɛt#", 
            "prog": "#mitɪŋ#", 
            "pres3sg": "#mits#", 
            "perfect": "#mɛt#" 
        },
        "mess": { 
            "bare": "#mɛs#", 
            "past": "#mɛst#",
            "prog": "#mɛsɪŋ#",
            "pres3sg": "#mɛsɪz#", 
            "perfect": "#mɛst#" 
        },
        "might": {
            "bare": "#maɪt#",
            "past": "#maɪt#",
            "prog": "No Progressive",
            "pres3sg": "#maɪt#",
            "perfect": "No Perfect Participle"
        },
        "mock": { 
            "bare": "#mɑk#", 
            "past": "#mɑkt#",
            "prog": "#mɑkɪŋ#",
            "pres3sg": "#mɑks#", 
            "perfect": "#mɑkt#" 
        },
        "must": {
            "bare": "#mʌst#",
            "past": "No Past Tense",
            "prog": "No Progressive",
            "pres3sg": "#mʌst#",
            "perfect": "No Perfect Participle"
        },
        "nag": { 
            "bare": "#næɡ#", 
            "past": "#næɡd#",
            "prog": "#næɡɪŋ#",
            "pres3sg": "#næɡz#", 
            "perfect": "#næɡd#" 
        },
        "need": { 
            "bare": "#nid#", 
            "past": "#nidɪd#",
            "prog": "#nidɪŋ#",
            "pres3sg": "#nidz#", 
            "perfect": "#nidɪd#" 
        },
        "negate": { 
            "bare": "#nɪɡeɪt#", 
            "past": "#nɪɡeɪtɪd#",
            "prog": "#nɪɡeɪtɪŋ#",
            "pres3sg": "#nɪɡeɪts#", 
            "perfect": "#nɪɡeɪtɪd#" 
        },
        "nest": { 
            "bare": "#nɛst#", 
            "past": "#nɛstɪd#",
            "prog": "#nɛstɪŋ#",
            "pres3sg": "#nɛsts#", 
            "perfect": "#nɛstɪd#" 
        },
        "obtain": { 
            "bare": "#əbteɪn#", 
            "past": "#əbteɪnd#",
            "prog": "#əbteɪnɪŋ#",
            "pres3sg": "#əbteɪnz#", 
            "perfect": "#əbteɪnd#" 
        },
        "open": {
            "bare": "#oʊpən#", 
            "past": "#oʊpənd#", 
            "prog": "#oʊpənɪŋ#", 
            "pres3sg": "#oʊpənz#", 
            "perfect": "#oʊpənd#" 
        },
        "oppose": { 
            "bare": "#əpoʊz#", 
            "past": "#əpoʊzd#",
            "prog": "#əpoʊzɪŋ#",
            "pres3sg": "#əpoʊzɪz#", 
            "perfect": "#əpoʊzd#" 
        },
        "pace": { 
            "bare": "#peɪs#", 
            "past": "#peɪst#",
            "prog": "#peɪsɪŋ#",
            "pres3sg": "#peɪsɪz#", 
            "perfect": "#peɪst#" 
        },
        "pack": { 
            "bare": "#pæk#", 
            "past": "#pækt#",
            "prog": "#pækɪŋ#",
            "pres3sg": "#pæks#", 
            "perfect": "#pækt#" 
        },
        "pay": { 
            "bare": "#peɪ#", 
            "past": "#peɪd#", 
            "prog": "#peɪɪŋ#", 
            "pres3sg": "#peɪz#", 
            "perfect": "#peɪd#" 
        },
        "peek": { 
            "bare": "#pik#", 
            "past": "#pikt#",
            "prog": "#pikɪŋ#",
            "pres3sg": "#piks#", 
            "perfect": "#pikt#" 
        },
        "perfect": { 
            "bare": "#pɝfɛkt#", 
            "past": "#pɝfɛktɪd#",
            "prog": "#pɝfɛktɪŋ#",
            "pres3sg": "#pɝfɛkts#", 
            "perfect": "#pɝfɛktɪd#" 
        },
        "predict": { 
            "bare": "#pɹɪdɪkt#", 
            "past": "#pɹɪdɪktɪd#",
            "prog": "#pɹɪdɪktɪŋ#",
            "pres3sg": "#pɹɪdɪkts#", 
            "perfect": "#pɹɪdɪktɪd#" 
        },
        "put": { 
            "bare": "#pʊt#", 
            "past": "#pʊt#", 
            "prog": "#pʊtɪŋ#", 
            "pres3sg": "#pʊts#", 
            "perfect": "#pʊt#" 
        },
        "quack": { 
            "bare": "#kwæk#", 
            "past": "#kwækt#",
            "prog": "#kwækɪŋ#",
            "pres3sg": "#kwæks#", 
            "perfect": "#kwækt#" 
        },
        "race": { 
            "bare": "#ɹeɪs#", 
            "past": "#ɹeɪst#",
            "prog": "#ɹeɪsɪŋ#",
            "pres3sg": "#ɹeɪsɪz#", 
            "perfect": "#ɹeɪst#" 
        },
        "react": { 
            "bare": "#ɹiækt#", 
            "past": "#ɹiæktɪd#",
            "prog": "#ɹiæktɪŋ#",
            "pres3sg": "#ɹiækts#", 
            "perfect": "#ɹiæktɪd#" 
        },
        "read": { 
            "bare": "#ɹid#",
            "past": "#ɹɛd#", 
            "prog": "#ɹidɪŋ#", 
            "pres3sg": "#ɹidz#", 
            "perfect": "#ɹɛd#" 
        },
        "ride": { 
            "bare": "#ɹaɪd#", 
            "past": "#ɹoʊd#", 
            "prog": "#ɹaɪdɪŋ#", 
            "pres3sg": "#ɹaɪdz#", 
            "perfect": "#ɹɪdən#" 
        },
        "ring": { 
            "bare": "#ɹɪŋ#", 
            "past": "#ɹæŋ#", 
            "prog": "#ɹɪŋɪŋ#", 
            "pres3sg": "#ɹɪŋz#", 
            "perfect": "#ɹʌŋ#" 
        },
        "rise": { 
            "bare": "#ɹaɪz#", 
            "past": "#ɹoʊz#", 
            "prog": "#ɹaɪzɪŋ#", 
            "pres3sg": "#ɹaɪzɪz#", 
            "perfect": "#ɹɪzən#" 
        },
        "run": { 
            "bare": "#ɹʌn#", 
            "past": "#ɹæn#", 
            "prog": "#ɹʌnɪŋ#", 
            "pres3sg": "#ɹʌnz#", 
            "perfect": "#ɹʌn#" 
        },
        "save": { 
            "bare": "#seɪv#", 
            "past": "#seɪvd#",
            "prog": "#seɪvɪŋ#",
            "pres3sg": "#seɪvz#", 
            "perfect": "#seɪvd#" 
        },
        "say": { 
            "bare": "#seɪ#", 
            "past": "#sɛd#", 
            "prog": "#seɪɪŋ#",
            "pres3sg": "#sɛz#", 
            "perfect": "#sɛd#" 
        },
        "scan": { 
            "bare": "#skæn#", 
            "past": "#skænd#",
            "prog": "#skænɪŋ#",
            "pres3sg": "#skænz#", 
            "perfect": "#skænd#" 
        },
        "seat": { 
            "bare": "#sit#", 
            "past": "#sitɪd#",
            "prog": "#sitɪŋ#",
            "pres3sg": "#sits#", 
            "perfect": "#sitɪd#" 
        },
        "see": { 
            "bare": "#si#", 
            "past": "#sɔ#", 
            "prog": "#siɪŋ#", 
            "pres3sg": "#siz#", 
            "perfect": "#sin#" 
        },
        "sell": { 
            "bare": "#sɛl#", 
            "past": "#soʊld#", 
            "prog": "#sɛlɪŋ#", 
            "pres3sg": "#sɛlz#",
            "perfect": "#soʊld#" 
        },
        "send": { 
            "bare": "#sɛnd#", 
            "past": "#sɛnt#", 
            "prog": "#sɛndɪŋ#", 
            "pres3sg": "#sɛndz#", 
            "perfect": "#sɛnt#" 
        },
        "set": { 
            "bare": "#sɛt#", 
            "past": "#sɛt#", 
            "prog": "#sɛtɪŋ#", 
            "pres3sg": "#sɛts#", 
            "perfect": "#sɛt#" 
        },
        "shall": {
            "bare": "#ʃæl#",
            "past": "#ʃʊd#",
            "prog": "No Progressive",
            "pres3sg": "#ʃæl#",
            "perfect": "No Perfect Participle"
        },
        "shine": { 
            "bare": "#ʃaɪn#", 
            "past": "#ʃoʊn#", 
            "prog": "#ʃaɪnɪŋ#", 
            "pres3sg": "#ʃaɪnz#", 
            "perfect": "#ʃoʊn#" 
        },
        "shoot": { 
            "bare": "#ʃut#", 
            "past": "#ʃɑt#", 
            "prog": "#ʃutɪŋ#", 
            "pres3sg": "#ʃuts#", 
            "perfect": "#ʃɑt#" 
        },
        "should": {
            "bare": "#ʃʊd#",
            "past": "#ʃʊd#",
            "prog": "No Progressive",
            "pres3sg": "#ʃʊd#",
            "perfect": "No Perfect Participle"
        },
        "show": { 
            "bare": "#ʃoʊ#", 
            "past": "#ʃoʊd#", 
            "prog": "#ʃoʊɪŋ#", 
            "pres3sg": "#ʃoʊz#", 
            "perfect": "#ʃoʊd#" 
        },
        "shut": { 
            "bare": "#ʃʌt#", 
            "past": "#ʃʌt#", 
            "prog": "#ʃʌtɪŋ#", 
            "pres3sg": "#ʃʌts#", 
            "perfect": "#ʃʌt#" 
        },
        "sing": { 
            "bare": "#sɪŋ#", 
            "past": "#sæŋ#", 
            "prog": "#sɪŋɪŋ#",
            "pres3sg": "#sɪŋz#", 
            "perfect": "#sʌŋ#" 
        },
        "sit": { 
            "bare": "#sɪt#", 
            "past": "#sæt#", 
            "prog": "#sɪtɪŋ#", 
            "pres3sg": "#sɪts#", 
            "perfect": "#sæt#" 
        },
        "sleep": { 
            "bare": "#slip#", 
            "past": "#slɛpt#", 
            "prog": "#slipɪŋ#", 
            "pres3sg": "#slips#", 
            "perfect": "#slɛpt#" 
        },
        "slide": { 
            "bare": "#slaɪd#", 
            "past": "#slɪd#", 
            "prog": "#slaɪdɪŋ#", 
            "pres3sg": "#slaɪdz#", 
            "perfect": "#slɪd#" 
        },
        "speak": { 
            "bare": "#spik#", 
            "past": "#spoʊk#", 
            "prog": "#spikɪŋ#", 
            "pres3sg": "#spiks#", 
            "perfect": "#spoʊkən#" 
        },
        "spend": { 
            "bare": "#spɛnd#", 
            "past": "#spɛnt#", 
            "prog": "#spɛndɪŋ#", 
            "pres3sg": "#spɛndz#", 
            "perfect": "#spɛnt#" 
        },
        "stand": { 
            "bare": "#stænd#", 
            "past": "#stʊd#", 
            "prog": "#stændɪŋ#", 
            "pres3sg": "#stændz#", 
            "perfect": "#stʊd#" 
        },
        "steal": { 
            "bare": "#stil#", 
            "past": "#stoʊl#", 
            "prog": "#stilɪŋ#", 
            "pres3sg": "#stilz#", 
            "perfect": "#stoʊlən#" 
        },
        "stick": { 
            "bare": "#stɪk#",
            "past": "#stʌk#", 
            "prog": "#stɪkɪŋ#", 
            "pres3sg": "#stɪks#", 
            "perfect": "#stʌk#" 
        },
        "strike": { 
            "bare": "#stɹaɪk#", 
            "past": "#stɹʌk#", 
            "prog": "#stɹaɪkɪŋ#", 
            "pres3sg": "#stɹaɪks#", 
            "perfect": "#stɹʌk#" 
        },
        "swear": { 
            "bare": "#swɛɹ#", 
            "past": "#swɔɹ#", 
            "prog": "#swɛɹɪŋ#", 
            "pres3sg": "#swɛɹz#", 
            "perfect": "#swɔɹn#" 
        },
        "sweep": { 
            "bare": "#swip#",
            "past": "#swɛpt#", 
            "prog": "#swipɪŋ#", 
            "pres3sg": "#swips#", 
            "perfect": "#swɛpt#" 
        },
        "swim": { 
            "bare": "#swɪm#", 
            "past": "#swæm#", 
            "prog": "#swɪmɪŋ#", 
            "pres3sg": "#swɪmz#", 
            "perfect": "#swʌm#" 
        },
        "swing": { 
            "bare": "#swɪŋ#",
            "past": "#swʌŋ#", 
            "prog": "#swɪŋɪŋ#", 
            "pres3sg": "#swɪŋz#",
            "perfect": "#swʌŋ#" 
        },
        "take": { 
            "bare": "#teɪk#", 
            "past": "#tʊk#", 
            "prog": "#teɪkɪŋ#", 
            "pres3sg": "#teɪks#", 
            "perfect": "#tʊk#" 
        },
        "take": {
            "bare": "#teɪk#", 
            "past": "#tʊk#", 
            "prog": "#teɪkɪŋ#", 
            "pres3sg": "#teɪks#", 
            "perfect": "#teɪkən#" 
        },
        "teach": { 
            "bare": "#titʃ#", 
            "past": "#tɔt#", 
            "prog": "#titʃɪŋ#", 
            "pres3sg": "#titʃɪz#", 
            "perfect": "#tɔt#" 
        },
        "tease": { 
            "bare": "#tiz#", 
            "past": "#tizd#",
            "prog": "#tizɪŋ#",
            "pres3sg": "#tizɪz#", 
            "perfect": "#tizd#" 
        },
        "tell": { 
            "bare": "#tɛl#", 
            "past": "#toʊld#", 
            "prog": "#tɛlɪŋ#", 
            "pres3sg": "#tɛlz#", 
            "perfect": "#toʊld#" 
        },
        "think": { 
            "bare": "#θɪŋk#", 
            "past": "#θɔt#", 
            "prog": "#θɪŋkɪŋ#", 
            "pres3sg": "#θɪŋks#", 
            "perfect": "#θɔt#" 
        },
        "throw": { 
            "bare": "#θɹoʊ#", 
            "past": "#θɹu#", 
            "prog": "#θɹoʊɪŋ#",
            "pres3sg": "#θɹoʊz#", 
            "perfect": "#θɹoʊn#" 
        },
        "tip": { 
            "bare": "#tɪp#", 
            "past": "#tɪpt#",
            "prog": "#tɪpɪŋ#",
            "pres3sg": "#tɪps#", 
            "perfect": "#tɪpt#" 
        },
        "understand": { 
            "bare": "#ʌndəɹstænd#", 
            "past": "#ʌndəɹstʊd#", 
            "prog": "#ʌndəɹstændɪŋ#", 
            "pres3sg": "#ʌndəɹstændz#", 
            "perfect": "#ʌndəɹstʊd#" 
        },
        "untie": { 
            "bare": "#ʌntaɪ#", 
            "past": "#ʌntaɪd#",
            "prog": "#ʌntaɪŋ#",
            "pres3sg": "#ʌntaɪz#", 
            "perfect": "#ʌntaɪd#" 
        },
        "value": { 
            "bare": "#vælju#", 
            "past": "#væljud#",
            "prog": "#væljuɪŋ#",
            "pres3sg": "#væljuz#", 
            "perfect": "#væljud#" 
        },
        "vend": { 
            "bare": "#vɛnd#", 
            "past": "#vɛndɪd#",
            "prog": "#vɛndɪŋ#",
            "pres3sg": "#vɛndz#", 
            "perfect": "#vɛndɪd#" 
        },
        "vent": { 
            "bare": "#vɛnt#", 
            "past": "#vɛntɪd#",
            "prog": "#vɛntɪŋ#",
            "pres3sg": "#vɛnts#", 
            "perfect": "#vɛntɪd#" 
        },
        "wait": { 
            "bare": "#weɪt#", 
            "past": "#weɪtɪd#",
            "prog": "#weɪtɪŋ#",
            "pres3sg": "#weɪts#", 
            "perfect": "#weɪtɪd#" 
        },
        "wake": { 
            "bare": "#weɪk#", 
            "past": "#woʊk#", 
            "prog": "#weɪkɪŋ#", 
            "pres3sg": "#weɪks#", 
            "perfect": "#woʊkən#" 
        },
        "wear": { 
            "bare": "#wɛɹ#", 
            "past": "#wɔɹ#", 
            "prog": "#wɛɹɪŋ#", 
            "pres3sg": "#wɛɹz#", 
            "perfect": "#wɔɹn#" 
        },
        "want": { 
            "bare": "#wɑnt#", 
            "past": "#wɑntɪd#",
            "prog": "#wɑntɪŋ#",
            "pres3sg": "#wɑnts#", 
            "perfect": "#wɑntɪd#" 
        },
        "waste": { 
            "bare": "#weɪst#", 
            "past": "#weɪstɪd#",
            "prog": "#weɪstɪŋ#",
            "pres3sg": "#weɪsts#", 
            "perfect": "#weɪstɪd#" 
        },
        "will": {
            "bare": "#wɪl#",
            "past": "#wʊd#",
            "prog": "No Progresive",
            "pres3sg": "#wɪl#",
            "perfect": "No Perfect Participle"
        },
        "win": { 
            "bare": "#wɪn#", 
            "past": "#wʌn#", 
            "prog": "#wɪnɪŋ#", 
            "pres3sg": "#wɪnz#", 
            "perfect": "#wʌn#" 
        },
        "would": {
            "bare": "#wʊd#",
            "past": "#wʊd#",
            "prog": "No Progresive",
            "pres3sg": "#wʊd#",
            "perfect": "No Perfect Participle"
        },
        "write": { 
            "bare": "#ɹaɪt#", 
            "past": "#ɹoʊt#", 
            "prog": "#ɹaɪtɪŋ#", 
            "pres3sg": "#ɹaɪts#", 
            "perfect": "#ɹɪtən#"
        },
        "yap": { 
            "bare": "#jæp#", 
            "past": "#jæpt#",
            "prog": "#jæpɪŋ#",
            "pres3sg": "#jæps#", 
            "perfect": "#jæpt#" 
        },
        "yawn": { 
            "bare": "#jɔn#", 
            "past": "#jɔnd#",
            "prog": "#jɔnɪŋ#",
            "pres3sg": "#jɔnz#", 
            "perfect": "#jɔnd#" 
        },
        "yell": { 
            "bare": "#jɛl#", 
            "past": "#jɛld#",
            "prog": "#jɛlɪŋ#",
            "pres3sg": "#jɛlz#", 
            "perfect": "#jɛld#" 
        },
        "zap": { 
            "bare": "#zæp#", 
            "past": "#zæpt#",
            "prog": "#zæpɪŋ#",
            "pres3sg": "#zæps#", 
            "perfect": "#zæpt#" 
        },
        "zoom": { 
            "bare": "#zum#", 
            "past": "#zumd#",
            "prog": "#zumɪŋ#",
            "pres3sg": "#zumz#", 
            "perfect": "#zumd#" 
        }

    }

    return verbs_ipa